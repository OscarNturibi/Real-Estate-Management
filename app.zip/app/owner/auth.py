#!/usr/bin/python3
"""Authentication routes and helpers for owner module"""

from flask import Blueprint, jsonify, request
from werkzeug.security import check_password_hash
from flask_login import login_required, logout_user, current_user
from app.models import Owner
from app import db

auth_bp = Blueprint("owner_auth", __name__, url_prefix="/owner")


@auth_bp.route("/login", methods=["POST"])
def owner_login():
    """Owner login route"""
    data = request.get_json()

    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"error": "Missing email or password"}), 400

    owner = Owner.query.filter_by(email=email).first()

    if not owner or not check_password_hash(owner.password, password):
        return jsonify({"error": "Invalid credentials"}), 401

    return jsonify({
        "message": "Owner login successful",
        "owner_id": owner.id
    }), 200


@auth_bp.route("/status", methods=["GET"])
@login_required
def auth_status():
    """Check if user is authenticated"""
    return jsonify({
        "authenticated": True,
        "user": {
            "id": current_user.id,
            "username": current_user.username,
            "email": current_user.email
        }
    }), 200


@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    """Logs out the current user"""
    logout_user()
    return jsonify({"message": "Logout successful"}), 200


@auth_bp.route("/unauthorized")
def unauthorized():
    """For React unauthorized requests"""
    return jsonify({"error": "Unauthorized access"}), 401
