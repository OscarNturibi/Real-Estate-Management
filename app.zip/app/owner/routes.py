from flask import Blueprint, request, jsonify
from app.models import User, db
from werkzeug.security import generate_password_hash

owner_bp = Blueprint('owner', __name__)

@owner_bp.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json()
    errors = {}

    # Basic validation
    if not data.get("email"): errors["email"] = "Email is required."
    if not data.get("password"): errors["password"] = "Password is required."
    if data.get("password") != data.get("confirm_password"):
        errors["confirm_password"] = "Passwords do not match."

    if errors:
        return jsonify({"errors": errors}), 400

    user = User(
        username=data["username"],
        email=data["email"],
        phone=data["phone"],
        location=data["location"],
        password=generate_password_hash(data["password"])
    )
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "Account created successfully!"}), 201
