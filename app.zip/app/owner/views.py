#!/usr/bin/python3
"""Owner Authentication & Profile API"""

from flask import Blueprint, request, jsonify
from flask_login import login_user, current_user, logout_user, login_required
from app import db, bcrypt
from app.models import Owner

owner_bp = Blueprint("owner_bp", __name__, url_prefix="/owner")

# ✅ Register Owner
@owner_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Missing JSON data"}), 400

    email = data.get("email")
    password = data.get("password")

    if Owner.query.filter_by(email=email).first():
        return jsonify({"error": "Email already registered"}), 400

    hashed_pw = bcrypt.generate_password_hash(password).decode("utf-8")

    new_owner = Owner(
        username=data.get("username"),
        email=email,
        phone=data.get("phone"),
        location=data.get("location"),
        password=hashed_pw
    )

    db.session.add(new_owner)
    db.session.commit()

    return jsonify({"message": "Account created successfully!"}), 201


# ✅ Login Owner
@owner_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing data"}), 400

    user = Owner.query.filter_by(email=data.get("email")).first()

    if user and bcrypt.check_password_hash(user.password, data.get("password")):
        login_user(user, remember=True)
        return jsonify({"message": "Login successful", "user_id": user.id}), 200

    return jsonify({"error": "Invalid email or password"}), 401


# ✅ Update Profile
@owner_bp.route("/account", methods=["PUT"])
@login_required
def update_account():
    data = request.get_json()

    current_user.username = data.get("username", current_user.username)
    current_user.phone = data.get("phone", current_user.phone)
    current_user.location = data.get("location", current_user.location)

    db.session.commit()
    return jsonify({"message": "Profile updated!"}), 200


# ✅ Logout Owner
@owner_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    return jsonify({"message": "Logout successful!"}), 200
