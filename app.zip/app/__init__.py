#!/usr/bin/python3
"""Database and app initialization using factory pattern"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_cors import CORS

db = SQLAlchemy()
migrate = Migrate()
bcrypt = Bcrypt()
login_manager = LoginManager()

def create_app():
    """App factory function"""
    app = Flask(__name__)

    # Configuration
    app.config['SECRET_KEY'] = 'RealtyHubapp'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///realtyhub.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    bcrypt.init_app(app)
    CORS(app, resources={r"/*": {"origins": "*"}})
    login_manager.init_app(app)

    login_manager.session_protection = "strong"
    login_manager.login_view = None  # React handles redirect

    # ✅ Register existing working blueprints only!
    from app.owner.views import owner_bp
    from app.owner.auth import auth_bp as owner_auth_bp
    from app.Property.views import property_bp

    app.register_blueprint(owner_bp)
    app.register_blueprint(owner_auth_bp)
    app.register_blueprint(property_bp)

    # ✅ Flask-Login user loader
    from app.models import Tenant, owner

    @login_manager.user_loader
    def load_user(user_id):
        user = owner.query.get(int(user_id))
        if not user:
            user = Tenant.query.get(int(user_id))
        return user

    return app
