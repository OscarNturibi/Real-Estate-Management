#!/usr/bin/python3
"""API endpoints for property management"""

import os
import secrets
from datetime import datetime
from PIL import Image
from werkzeug.utils import secure_filename
from flask import (
    jsonify, request, Blueprint, abort, current_app
)
from flask_login import current_user, login_required
from app import db
from app.models import Property, Tenant

# Blueprint
property_bp = Blueprint("property_bp", __name__, url_prefix="/api/property")


def save_picture(form_picture):
    """Save uploaded picture and create a thumbnail."""
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(current_app.root_path, "static/property_pics", picture_fn)

    # Ensure directory exists
    os.makedirs(os.path.dirname(picture_path), exist_ok=True)
    form_picture.save(picture_path)

    # Create thumbnail
    thumbnail_size = (300, 300)
    thumbnail_fn = random_hex + "_thumb" + f_ext
    thumbnail_path = os.path.join(current_app.root_path, "static/property_pics", thumbnail_fn)

    img = Image.open(form_picture)
    img.thumbnail(thumbnail_size)
    img.save(thumbnail_path)

    return picture_fn, thumbnail_fn


# ---------------------------
# Create Property (POST)
# ---------------------------
@property_bp.route("/add", methods=["POST"])
@login_required
def create_property():
    """Add a new property (owner only)."""
    if isinstance(current_user, Tenant):
        return jsonify({"error": "Tenants cannot create properties"}), 403

    data = request.form
    prop = Property(
        title=data.get("title"),
        description=data.get("description"),
        price=data.get("price"),
        location=data.get("location"),
        property_type=data.get("property_type"),
        property_status=data.get("property_status"),
        bedrooms=data.get("bedrooms"),
        bathrooms=data.get("bathrooms"),
        size=data.get("size"),
        available_from=data.get("available_from"),
        owner_id=current_user.id,
    )

    # Handle image uploads
    for idx in range(1, 4):
        img_file = request.files.get(f"image{idx}")
        if img_file:
            image_file, thumb_file = save_picture(img_file)
            setattr(prop, f"image{idx}", image_file)
            setattr(prop, f"thumbnail{idx}", thumb_file)

    db.session.add(prop)
    db.session.commit()

    return jsonify({"message": "Property created successfully", "property_id": prop.id}), 201


# ---------------------------
# Update Property (PUT)
# ---------------------------
@property_bp.route("/<int:property_id>", methods=["PUT"])
@login_required
def update_property(property_id):
    prop = Property.query.get_or_404(property_id)
    if prop.owner_id != current_user.id:
        abort(403)

    data = request.form
    for field in [
        "title", "description", "price", "location",
        "property_type", "bedrooms", "bathrooms", "size", "available_from"
    ]:
        if field in data:
            setattr(prop, field, data[field])

    for idx in range(1, 4):
        img_file = request.files.get(f"image{idx}")
        if img_file:
            image_file, thumb_file = save_picture(img_file)
            setattr(prop, f"image{idx}", image_file)
            setattr(prop, f"thumbnail{idx}", thumb_file)

    db.session.commit()
    return jsonify({"message": "Property updated successfully"}), 200


# ---------------------------
# Get Property Details (GET)
# ---------------------------
@property_bp.route("/<int:property_id>", methods=["GET"])
def get_property(property_id):
    prop = Property.query.get_or_404(property_id)
    return jsonify({
        "id": prop.id,
        "title": prop.title,
        "description": prop.description,
        "price": prop.price,
        "location": prop.location,
        "property_type": prop.property_type,
        "property_status": prop.property_status,
        "bedrooms": prop.bedrooms,
        "bathrooms": prop.bathrooms,
        "size": prop.size,
        "available_from": str(prop.available_from),
        "images": [prop.image1, prop.image2, prop.image3],
    }), 200


# ---------------------------
# Search Properties (GET)
# ---------------------------
@property_bp.route("/search", methods=["GET"])
def search_properties():
    query = Property.query

    # Filter params
    location = request.args.get("location")
    min_price = request.args.get("min_price", type=float)
    max_price = request.args.get("max_price", type=float)
    property_type = request.args.get("property_type")
    property_status = request.args.get("property_status")

    if location:
        query = query.filter(Property.location.ilike(f"%{location}%"))
    if min_price is not None:
        query = query.filter(Property.price >= min_price)
    if max_price is not None:
        query = query.filter(Property.price <= max_price)
    if property_type:
        query = query.filter(Property.property_type == property_type)
    if property_status:
        query = query.filter(Property.property_status == property_status)

    results = query.limit(20).all()
    return jsonify([{
        "id": p.id,
        "title": p.title,
        "price": p.price,
        "location": p.location,
        "type": p.property_type,
        "status": p.property_status,
        "thumbnail": p.thumbnail1
    } for p in results]), 200


# ---------------------------
# List All Properties (GET)
# ---------------------------
@property_bp.route("/list", methods=["GET"])
def get_properties():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 10, type=int)
    pagination = Property.query.paginate(page=page, per_page=per_page)
    properties = pagination.items

    return jsonify({
        "properties": [{
            "id": p.id,
            "title": p.title,
            "price": p.price,
            "location": p.location,
            "thumbnail": p.thumbnail1
        } for p in properties],
        "total": pagination.total,
        "page": page
    }), 200


# ---------------------------
# Delete Property (DELETE)
# ---------------------------
@property_bp.route("/<int:property_id>", methods=["DELETE"])
@login_required
def delete_property(property_id):
    prop = Property.query.get_or_404(property_id)
    if prop.owner_id != current_user.id:
        abort(403)

    db.session.delete(prop)
    db.session.commit()
    return jsonify({"message": "Property deleted successfully"}), 200
