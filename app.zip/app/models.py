#!/usr/bin/python3
"""Models for the property application."""

from datetime import datetime, date
from enum import Enum
from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Date,
    ForeignKey, Boolean, func
)
from sqlalchemy.orm import relationship
from flask_login import UserMixin
from app import db


class Users(UserMixin, db.Model):
    """Base user model for Owner and Tenant"""
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    username = Column(String(128), nullable=False)
    password = Column(String(128), nullable=False)
    email = Column(String(128), unique=True, nullable=False)
    phone = Column(String(128), nullable=False)
    image_file = Column(String(128), default='default.jpg')
    location = Column(String(128), nullable=False)

    def __repr__(self):
        return f"User('{self.username}', '{self.email}')"


class Owner(Users):
    """Owner model"""
    __tablename__ = 'owners'

    id = Column(Integer, ForeignKey('users.id'), primary_key=True)
    properties = relationship('Property', backref='owner', lazy=True)

    def __repr__(self):
        return f"Owner('{self.username}', '{self.email}')"


class Tenant(Users):
    """Tenant model"""
    __tablename__ = 'tenants'

    id = Column(Integer, ForeignKey('users.id'), primary_key=True)
    tenant_properties = relationship('TenantProperty', backref='tenant', lazy=True)

    def __repr__(self):
        return f"Tenant('{self.username}', '{self.email}')"


class TenantProperty(db.Model):
    """Many-to-many relationship between tenants and properties"""
    __tablename__ = 'tenant_properties'

    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, ForeignKey('tenants.id'), nullable=False)
    property_id = Column(Integer, ForeignKey('properties.id'), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    is_assigned = Column(Boolean, default=False)

    property = relationship('Property', backref='tenant_links')


class PropertyStatus(Enum):
    SALE = "sale"
    RENT = "rent"
    SOLD = "sold"
    RENTED = "rented"


class Property(db.Model):
    """Property model"""
    __tablename__ = 'properties'

    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    location = Column(String(200), nullable=False)
    price = Column(Integer, nullable=False)
    property_type = Column(String(200), nullable=False)
    property_status = Column(String(200), nullable=False)
    bathrooms = Column(Integer, nullable=False)
    bedrooms = Column(Integer, nullable=False)
    size = Column(Integer, nullable=False)
    available_from = Column(DateTime, default=func.current_timestamp())
    created_at = Column(DateTime, default=datetime.utcnow)
    owner_id = Column(Integer, ForeignKey('owners.id'))
    rentals = relationship('Rental', backref='property', lazy=True)

    # Images
    image1 = Column(String(100), nullable=True)
    thumbnail1 = Column(String(100), nullable=True)
    image2 = Column(String(100), nullable=True)
    thumbnail2 = Column(String(100), nullable=True)
    image3 = Column(String(100), nullable=True)
    thumbnail3 = Column(String(100), nullable=True)

    messages = relationship('Messages', backref='property', lazy=True)

    def __repr__(self):
        return f"Property('{self.title}', '{self.location}', '{self.price}')"

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'location': self.location,
            'price': self.price,
            'property_type': self.property_type,
            'property_status': self.property_status,
            'bathrooms': self.bathrooms,
            'bedrooms': self.bedrooms,
            'size': self.size,
            'available_from': self.available_from.isoformat(),
            'owner_id': self.owner_id,
            'created_at': self.created_at.isoformat(),
            'thumbnail1': self.thumbnail1,
            'thumbnail2': self.thumbnail2,
            'thumbnail3': self.thumbnail3
        }


class Rental(db.Model):
    __tablename__ = 'rentals'

    id = Column(Integer, primary_key=True)
    property_id = Column(Integer, ForeignKey('properties.id'), nullable=False)
    tenant_id = Column(Integer, ForeignKey('tenants.id'), nullable=False)
    contract_end_date = Column(Date, nullable=False)


class Messages(db.Model):
    __tablename__ = 'messages'

    id = Column(Integer, primary_key=True)
    sender_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    receiver_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    property_id = Column(Integer, ForeignKey('properties.id'))
    message = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    read = Column(Boolean, default=False)

    sender = relationship('Users', foreign_keys=[sender_id])
    receiver = relationship('Users', foreign_keys=[receiver_id])


class Application(db.Model):
    __tablename__ = "applications"

    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, ForeignKey("tenants.id"), nullable=False)
    property_id = Column(Integer, ForeignKey("properties.id"), nullable=False)
    status = Column(String(50), default="Pending")
    created_at = Column(DateTime, default=datetime.utcnow)

    tenant = relationship("Tenant", backref="applications")
    property = relationship("Property", backref="applications")

    def __repr__(self):
        return f"Application(Tenant={self.tenant_id}, Property={self.property_id}, Status={self.status})"
